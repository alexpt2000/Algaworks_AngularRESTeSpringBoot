import { Component } from '@angular/core';

@Component({
  selector: 'ngx-dropdown-buttons',
  styleUrls: ['./dropdown-button.component.scss'],
  templateUrl: './dropdown-button.component.html',
})

export class DropdownButtonsComponent {
}
